<strong>hello new email from</strong>
<strong>Name: </strong><?php echo e($request->name); ?><br>
<strong>Email: </strong><?php echo e($request->email); ?><br>
<strong>Message: </strong><?php echo e($request->message); ?><br>
