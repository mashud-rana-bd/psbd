<strong>hello new email from</strong>
<strong>Name: </strong>{{$request->name}}<br>
<strong>Email: </strong>{{$request->email}}<br>
<strong>Message: </strong>{{$request->message}}<br>
